// These functions are specific to my zipped demo page, not my online page.

// What you do with the results is up to you.
// Typically, I detect the fonts immediately after the body tag is written, but before page content.
// If you intend to use the result to change style sheets, then you can do it immediately.
// But if you intend to display the results on the page, then you have to wait until later.
// In that case, use either window.onload, or call the result function using inline script.
// For this demo page, I call useTestFontResult() by inline script, after the containing div is written.

// Results are kept in testFontResult[index] array. I use "yes" or "no" as possible results.

// Since the displayTestFontResult() function places text into the document body,
// This function is invoked after a certain div element (which will contain the text)
// has been written.


function displayTestFontResult() {
    if(document.getElementById("theFontResultDiv")) {
        fontresultdiv = document.getElementById("theFontResultDiv");
        var hasResults = true;
        try {if(testFontResult[0]=="") void(0);}
        catch(e) {hasResults = false;}
        if(hasResults) {
            var thisfont;
            var tf = testFontList.length;
            fontResultExhibit = new Array();
            fontResultExhibitText = new Array();
            for(var n=0; tf>n; n++) {
                thisfont = testFontList[n];
                if(thisfont != "") {
                    thisfont = thisfont + " = " + testFontResult[n];
                    fontResultExhibitText[n] = document.createTextNode(thisfont);
                    fontResultExhibit[n] = document.createElement("div");
                    fontResultExhibit[n].style.marginLeft = "20px";
                    if(n == (tf-1)) fontResultExhibit[n].style.marginBottom = "20px";
                    fontResultExhibit[n].appendChild(fontResultExhibitText[n]);
                    fontresultdiv.appendChild(fontResultExhibit[n]);
                }
            }
        }
        else {
            noFontTestResult = document.createTextNode("List of fonts was not specified.");
            noFontTestResultDiv = document.createElement("div");
            noFontTestResultDiv.style.marginLeft = "20px";
            noFontTestResultDiv.style.marginBottom = "20px";
            noFontTestResultDiv.appendChild(noFontTestResult);
            fontresultdiv.appendChild(noFontTestResultDiv);
        }
    }
}

function changeSmallFonts() {
  var undefined;
  var sheetNumber = 0;  // see explanation below
  var ruleNumber = 1;  // see explanation below
  if((document.styleSheets) && (document.styleSheets.length) > sheetNumber) {
    var thisSheet = document.styleSheets[sheetNumber];
    if((thisSheet.cssRules) && ((thisSheet.cssRules[ruleNumber]) != undefined)) {
      thisSheet.cssRules[ruleNumber].style.fontSize = "14px";  //  test appropriate for most non-MS browsers
    }
    else {
        if((thisSheet.rules) && ((thisSheet.rules[ruleNumber]) != undefined)) {
          thisSheet.rules[ruleNumber].style.fontSize = "14px";  // test appropriate for most MS browsers
        }
    }
  }
}

// Explanation of sheetNumber and ruleNumber (these are my own variable names):
// In this context, a "style sheet" includes both external *.css files,
// and internal script elements in the document head. (I'm not sure how @import rules are counted.)
// The browser keep its style sheets in an array called document.styleSheets.
// Each style sheet is indexed, with 0 being the first encountered from the top of the document head.
// In my font-detector.htm file, document.styleSheets[0] is the internal style element.
// In this "style sheet," the "cssRules" (most browsers other than Microsoft)
// or the "rules" (most Microsoft browsers) are the various element styles.
// It is necessary to branch the logic so that either "cssRules" or "rules" can be used without error.
// For each style sheet, the rules are kept in an array, indexed from 0 for the topmost rule.
// In my style sheet, rule 1 has the style for p.changeme class.
// Fonts are detected before any content text is displayed in the document body.
// If Verdana is not present, then the font-size style for p.changeme is rasied from 12px to 14px.
// Note that CSS font-size is JavaScript fontSize.

// If you wish to be fancy, you could write script that determines which sheet has which rules,
// so that you don't need to know the index numbers in advance.
// That might be necessary if you have several un-coordinated pages on your web site.
// In my case, all pages use the same organization, so I know in advance where things are.

// If you wish to know where I got this kind of scripting information, surf the Internet for
// DOM CSS.



gotScript = true;  // This is for my own use.
