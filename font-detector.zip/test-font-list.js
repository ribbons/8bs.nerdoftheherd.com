function getTestFontList() {
        testFontList[0] = "Verdana";
        testFontList[1] = "Georgia";
        testFontList[2] = "'Times New Roman', Times";  // almost always present
        testFontList[3] = "Arial";
        testFontList[4] = "'Comic Sans MS'";
        testFontList[5] = "'Apple Chancery'";
        testFontList[6] = "Palatino";
        testFontList[7] = "'Palatino Linotype'";
        testFontList[8] = "'Lucida Console'";
        testFontList[9] = "'Nonexistent Dummy'";  // always missing
        testFontList[10] = "'Nimbus Roman No9 L'";
        testFontList[11] = "MusiQwik";
        testFontList[12] = "Helvetica";
        testFontList[13] = "PostCrypt";
    var hasMoreFonts = true;
    try {hasMoreFonts = getMoreTestFontList();}
    catch(e) {hasMoreFonts = false;}
    if(hasMoreFonts) hasMoreFonts = getMoreTestFontList();
    return true;
}


// You do not need to use consecutive index numbers for the test font list.
// If you skip any numbers, the detection understands the omission.

// Each entry in testFontList includes one or more font names.
// If a font name has more than one word, then enclose the name in single quotes.
// Within a single entry, separate font names by a comma. Space is optional.
// When several fonts are in the same entry, detection is positive if any one or more are detected.

// Font names must be exact. 'Comic Sans MS' is a font name, but "Comic Sans' is not a font name.
// 'Palatino Linotype' and Palatino are two different (but similar) fonts.
// Names are usually case-sensitive.

// Do not use generic names such as serif, sans-serif, or monospace.

// Do not attempt to test for common dingbat or symbolic fonts,
// such as Webdings, Wingdings, Symbol, or Zapf Dingbats.
// Some browsers will report false positives, others will report false negatives, for such fonts.
// Many rare "amateur" dingbat fonts can be detected (such as my own MusiQwik),
// but it is unlikely that many visitors will have those fonts.

// Some systems have tables of equivalent fonts. For example, it appears that
// Windows regards Helvetica and Arial as equivalent. The test for Helvetica may
// be positive, even if the font is missing, because the system will substitute Arial.
// Such false positives are usually not an item of concern.

// My script allows you to put the font list in more than one block.
// So, you could test some fonts in common script for all your pages,
// plus additional fonts for a specific page.
// The master list is kept within the function getTestFontList(),
// and the individual entries are kept as testFontList[index].
// If you create a function getMoreTestFontList(),
// Then you can include addition testFontList[index] entries within it.
// After the additional fonts, the final line in getMoreTestFontList() must be:
// return true;
