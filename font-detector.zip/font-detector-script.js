var testString = "i";
var detectedResponse = "yes";
var undetectedResponse = "no";

// You may change the above variables. But do not use true and false for the responses.

function detectTestFonts() {
    if(document.createElement) {
        testFontList = new Array();
        var hasFonts = true;
        try {hasFonts = getTestFontList();}
        catch(e) {hasFonts = false;}
        if(hasFonts) {
            placeTestFontSpans();
            if(testFontResult[0] == undetectedResponse) changeSmallFonts();  // Optional.
        }
    }
}

function placeTestFontSpans() {
    if((testFontList.length) > 0) {
        var undefined;
        var tf = testFontList.length;
        testfontdiv = document.getElementById("theTestFontDiv");
        if(testfontdiv) {
            testFontSpan = new Array();
            testFontChar = new Array();
            testMonoSpan = document.createElement("span");
            testMonoSpan.style.fontFamily = "monospace";
            testMonoChar = document.createTextNode(testString);
            testMonoSpan.appendChild(testMonoChar);
            testfontdiv.appendChild(testMonoSpan);
            testSerifSpan = document.createElement("span");
            testSerifSpan.style.fontFamily = "serif";
            testSerifChar = document.createTextNode(testString);
            testSerifSpan.appendChild(testSerifChar);
            testfontdiv.appendChild(testSerifSpan);
            for(var n=0; tf>n; n++) {
                if(testFontList[n]==undefined) testFontList[n] = "";
                testFontSpan[n] = document.createElement("span");
                testFontSpan[n].style.fontFamily = testFontList[n] + ",monospace";
                testFontChar[n] = document.createTextNode(testString);
                testFontSpan[n].appendChild(testFontChar[n]);
                testFontSpan[tf+n] = document.createElement("span");
                testFontSpan[tf+n].style.fontFamily = testFontList[n] + ",serif";
                testFontChar[tf+n] = document.createTextNode(testString);
                testFontSpan[tf+n].appendChild(testFontChar[tf+n]);
            }
            testFontSpan[2*tf] = document.createElement("span");
            testFontSpan[2*tf].fontFamily = "monospace";
            testFontChar[2*tf] = document.createTextNode(testString);
            testFontSpan[2*tf].appendChild(testFontChar[2*tf]);
            for(var n=0; (2*tf)>=n; n++) {
                testfontdiv.appendChild(testFontSpan[n]);
            }
            testfontdiv.style.display = "block";
            var referenceMonoResult = getXposition(testSerifSpan) - getXposition(testMonoSpan);
            var referenceSerifResult = getXposition(testFontSpan[0]) - getXposition(testSerifSpan);
            testFontResult = new Array();
            for(var n=0; tf>n; n++) {
                var monoFontResult = getXposition(testFontSpan[n+1]) - getXposition(testFontSpan[n]);
                var serifFontResult = getXposition(testFontSpan[tf+n+1]) - getXposition(testFontSpan[tf+n]);
                var totalResult = (monoFontResult != referenceMonoResult) || (serifFontResult != referenceSerifResult);
                if(totalResult == true) testFontResult[n] = detectedResponse;
                else testFontResult[n] = undetectedResponse;
            }
            testfontdiv.style.display = "none"
        }
    }
}

// functions getXposition() and getYposition() thanks to www.quirksmode.org

function getYposition(whichelement) {
    var ypos = 0;
    if (whichelement.offsetParent) {
        while (whichelement.offsetParent) {
            ypos += whichelement.offsetTop
            whichelement = whichelement.offsetParent;
        }
    }
    return ypos;
}

function getXposition(whichelement) {
    var xpos = 0;
    if (whichelement.offsetParent) {
        while (whichelement.offsetParent) {
            xpos += whichelement.offsetLeft
            whichelement = whichelement.offsetParent;
        }
    }
    return xpos;
}


// After test, the names of the tested fonts are in array testFontList[n]
// The results of the tests are in array testFontResult[n]
// If you did not provide a testFontList[index] entry for a particular index,
// then testFontList[index] will be the empty string "".
