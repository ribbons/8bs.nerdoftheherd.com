BBC BASIC to ASCII text file converter.
v1.07 07/02/1999

At the moment it is fully BASIC I and BASIC II compatible and I will add BASIC IV shortly.
There are both 16bit and 32bit executables included in this zip so you will be able to use it in both DOS and a Windows DOS session.

Contributers to this code are:
Liam Corner
Robert Schmidt
Dan Little
Mark Usher

The code is public domain.
